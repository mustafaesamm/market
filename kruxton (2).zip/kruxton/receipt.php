<?php 
include 'db_connect.php';
$order = $conn->query("SELECT * FROM orders where id = {$_GET['id']}");
foreach($order->fetch_array() as $k => $v){
	$$k= $v;
}
?>

<style>
	.flex{
		display: inline-flex;
		width: 100%;
	}
	.w-50{
		width: 50%;
	}
	.text-center{
		text-align:center;
	}
	.text-right{
		text-align:right;
	}
	table.wborder{
		width: 100%;
		border-collapse: collapse;
	}
	table.wborder>tbody>tr, table.wborder>tbody>tr>td{
		border:1px solid;
	}
	p{
		margin:unset;
	}

</style>
<div class="container-fluid">
	<h1 class="text-center"><b><?php echo $amount_tendered > 0 ? "اسواق الهمام" : "Bill" ?></b></h1>
	<hr>
			<!--  -->
			<!-- <?php if($amount_tendered > 0): ?>
			<h3>رقم فاتورة الشراء: <b><?php echo $ref_no ?></b></h3>
		<?php endif; ?> -->
		<!--  -->

<h3  class='text-center'>وقت الشراء</h3>
			<h3 class='text-center'><b><?php echo date('Y-m-d H:i:s') ?></b></h3>
		
	<hr>
	<h3 class='text-center'><b>قائمة المواد</b></h3>
	<hr>
	<table width="100%">
		<thead>
			<tr>
				<td><h3>الكمية</h3></td>
				<td class="text-center"><h3>المادة</h3></td>
				<td class="text-right"><h3>المجموع</h3></td>
			</tr>
		</thead>
		<tbody>
			<?php
			$minussPrice=0;
			$items = $conn->query("SELECT o.*,p.name FROM order_items o inner join products p on p.id = o.product_id where o.order_id = $id  ");
			while($row = $items->fetch_assoc()):
				if($row['casee']){
					$color='color:black';
					$minuss=null;
						}else{
					$color='color:red';
					$minuss='-';
					$minussPrice +=$row['price'];
						}
			?>
			<tr style='<?php echo $color; ?>'>
				<td ><h3><?php echo $minuss.$row['qty'] ?></h3></td>
				<td><h3><?php echo $row['name'] ?></h3><?php if($row['qty'] > 0): ?><small>(<?php echo number_format($row['price'],2) ?>)</small> <?php endif; ?></td>
				<td class="text-right"><h3><?php echo number_format($row['amount'],2) ?></h3></td>
			</tr>
			<?php endwhile; ?>
		</tbody>
	</table>
	<hr>
	<table width="100%">
		<tbody>
			<!-- <tr>
				<td><h3>مجموع المواد</h3></td>
				<td class="text-right"><h3><?php echo number_format($total_amount,2) ?></h3></td>
			</tr> -->
			<?php if($amount_tendered > 0): ?>
			<tr>
				<td><h3>المبلغ المدفوع</h3></td>
				<td class="text-right"><h3><?php echo number_format($amount_tendered,2) ?></h3></td>
			</tr>
			<?php if($minussPrice != 0): ?>
			<tr>
				<td><h3>مبلغ المواد المسترجعة</h3></td>
				<td class="text-right"><h3><?php echo number_format($minussPrice,2) ?></h3></td>
			</tr>
			<tr>
				<td><h3>المبلغ المسترجع</h3></td>
				<td class="text-right"><h3><?php echo number_format($total_amount - $minussPrice ,2) ?></h3></td>
			</tr>
			<?php endif; ?>
		<?php endif; ?>
			
		</tbody>
	</table>
	<hr>
	<p class="text-center"><b>رقم الطلب.</b></p>
	<h4 class="text-center"><b><?php echo $order_number ?></b></h4>
</div>