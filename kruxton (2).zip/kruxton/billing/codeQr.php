<?php include '../db_connect.php' ;

if(isset($_GET['code'])){

$ProductCode=$_GET['code'];
 $qry = $conn->query("SELECT * FROM products  where QrCode like $ProductCode  order by name asc");
 while($row=$qry->fetch_assoc()):
 echo  json_encode($row);
 endwhile;

 }

 if(isset($_GET['codeRetrieving']) && isset($_GET['receiptNumber'])):

     $ProductCode=$_GET['codeRetrieving'];
     $receiptNumber=$_GET['receiptNumber'];
     $qry = $conn->query("SELECT * FROM products  where QrCode like $ProductCode  order by name asc");
     while($row=$qry->fetch_assoc()):
        $thePrice=$row['price'];
        $id=$row['id'];
     echo  json_encode($row);
     endwhile;
     $qry = $conn->query("INSERT INTO order_items(order_id,price,qty,product_id,amount) Values($receiptNumber,$thePrice,1,$id,$thePrice) ");
    
    endif;
?>