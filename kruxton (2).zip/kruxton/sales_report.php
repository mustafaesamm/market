<?php
    include 'db_connect.php';
    $month = isset($_GET['month']) ? $_GET['month'] : date('Y-m');
?>
<div class="container-fluid">
    <div class="col-lg-12">
        <div class="card">
            <div class="card_body">
            <div class="row justify-content-center pt-4">
                <label for="" class="mt-2">التاريخ</label>
                <div class="col-sm-3">
                    <input type="date" name="month" id="month" value="<?php echo date('Y-m-d') ?>" class="form-control">
                </div>
            </div>
            <hr>
            <div class="col-md-12">
                <table class="table table-bordered" id='report-list'>
                    <thead>
                        <tr>
                            <th class="text-center">#</th>
                            <th class="">التاريخ</th>
                            <!-- <th class="">Invoice</th> -->
                            <th class="">رقم الطلب</th>
                            <th class="">المبلغ</th>
                        </tr>
                    </thead>
                    <!--  Orginal Author Name: Mayuri K. 
 for any PHP, Codeignitor, Laravel OR Python work contact me at mayuri.infospace@gmail.com  
 Visit website : www.mayurik.com -->  
                    <tbody>
			          <?php
                      $i = 1;
                      $total = 0;
                      $amount_tendered = 0;
                      $salesMinuss = $conn->query("SELECT sum(price) FROM order_items where casee like '0'  ")->fetch_column();
                      $sales = $conn->query("SELECT * FROM orders where amount_tendered > 0 and date_created like '%$month%' order by date_created asc ");
                      if($sales->num_rows > 0):
			          while($row = $sales->fetch_array()):
                        $total += $row['total_amount'];
                        $amount_tendered += $row['amount_tendered'];
			          ?>
			          <tr>
                        <td class="text-center"><?php echo $i++ ?></td>
                        <td>
                            <p> <b><?php echo date("M d,Y",strtotime($row['date_created'])) ?></b></p>
                        </td>
                        <!-- <td>
                            <p> <b><?php echo $row['amount_tendered'] > 0 ? $row['ref_no'] : 'N/A' ?></b></p>
                        </td> -->
                        <td>
                            <p> <b><?php echo $row['order_number'] ?></b></p>
                        </td>
                        <td>
                            <p class="text-right"> <b><?php echo number_format($row['total_amount'],2) ?></b></p>
                        </td>
                    </tr>
                    <?php 
                        endwhile;
                        else:
                    ?>
                    <tr>
                            <th class="text-center" colspan="5">No Data.</th>
                    </tr>
                    <?php 
                        endif;
                    ?>
			        </tbody>
                    <tfoot>
                        <tr>
                            <th colspan="3" class="text-right">مجموع المبيعات</th>
                            <th class="text-right"><?php   echo number_format($total) ?></th>
                        </tr>
                        <tr>
                            <th colspan="3" class="text-right">مبالغ المواد المسترجعة</th>
                            <th class="text-right"><?php   echo number_format($salesMinuss); ?></th>
                        </tr>
                        <tr>
                            <th colspan="3" class="text-right">مجموع المبالغ</th>
                            <th class="text-right"><?php echo number_format($amount_tendered-$salesMinuss) ?></th>
                        </tr>
                        
                    </tfoot>
                </table>
                <hr>
                <div class="col-md-12 mb-4">
                    <center>
                        <button class="btn btn-success btn-sm col-sm-3" type="button" id="print"><i class="fa fa-print"></i> طباعة تقرير المبيعات</button>
                    </center>
                </div>
            </div>
            </div>
        </div>
    </div>
</div>
<noscript>
	<style>
		table#report-list{
			width:100%;
			border-collapse:collapse
		}
		table#report-list td,table#report-list th{
			border:1px solid
		}
        p{
            margin:unset;
        }
		.text-center{
			text-align:center
		}
        .text-right{
            text-align:right
        }
	</style>
</noscript>
<script>
$('#month').change(function(){
    location.replace('index.php?page=sales_report&month='+$(this).val())
})
$('#print').click(function(){
		var _c = $('#report-list').clone();
		var ns = $('noscript').clone();
            ns.append(_c)
		var nw = window.open('','_blank','width=900,height=600')
		nw.document.write('<p class="text-center"><b>تقرير المبيعات ليوم :  <?php echo date("Y-m-d",strtotime($month)) ?></b></p><br><br>')
		nw.document.write(ns.html())
		nw.document.close()
		nw.print()
		setTimeout(() => {
			nw.close()
		}, 500);
	})
</script>
<!--  Orginal Author Name: Mayuri K. 
 for any PHP, Codeignitor, Laravel OR Python work contact me at mayuri.infospace@gmail.com  
 Visit website  - www.mayurik.com  -->  