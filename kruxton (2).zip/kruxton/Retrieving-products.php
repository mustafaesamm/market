<?php session_start(); ?>
<?php include 'db_connect.php' ?>
<?php include 'header.php' ?>
<?php include 'topbar.php' ?>
<?php $theReceiptNumber=$_GET['receiptNumber']  ?>
<style>
   span.float-right.summary_icon {
    font-size: 3rem;
    position: absolute;
    right: 1rem;
    top: 0;
}
    .bg-gradient-primary{
        background: rgb(119,172,233);
        background: linear-gradient(149deg, rgba(119,172,233,1) 5%, rgba(83,163,255,1) 10%, rgba(46,51,227,1) 41%, rgba(40,51,218,1) 61%, rgba(75,158,255,1) 93%, rgba(124,172,227,1) 98%);
    }
    .btn-primary-gradient{
        background: linear-gradient(to right, #1e85ff 0%, #00a5fa 80%, #00e2fa 100%);
    }
    .btn-danger-gradient{
        background: linear-gradient(to right, #f25858 7%, #ff7840 50%, #ff5140 105%);
    }
    main .card{
        height:calc(100%);
    }
    main .card-body{
        height:calc(100%);
        overflow: auto;
        padding: 5px;
        position: relative;
    }
    main .container-fluid, main .container-fluid>.row,main .container-fluid>.row>div{
        /*height:calc(100%);*/
    }
    #o-list{
       
        overflow: auto;
    }
    #calc{
        position: absolute;
        bottom: 1rem;
        height: calc(10%);
        width: calc(98%);
    }
    .prod-item{
        min-height: 12vh;
        cursor: pointer;
    }
    .prod-item:hover{
        opacity: .8;
    }
    .prod-item .card-body {
        display: flex;
        justify-content: center;
        align-items: center;

    }
    input[name="qty[]"]{
        width: 30px;
        text-align: center
    }
    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
      -webkit-appearance: none;
      margin: 0;
    }
    #cat-list{
        /*height: calc(100%)*/
    }
    .cat-item{
        cursor: pointer;
    }
    .cat-item:hover{
        opacity: .8;
    }
</style>
<?php  
if(isset($_GET['receiptNumber'])){
?>

<div class="modal fade " style='direction:ltr' id="exampleModalCenter1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog  modal-xl  " role="document">
    <div class="modal-content">
      <div class="modal-header">
    
<h5 class='modal-title '>استرجاع</h5><h5 class='modal-title'>مواد الفاتورة</h5><h5 class='text-right modal-title '>NO.<?php echo $theReceiptNumber ;?></h5>
       
      </div>
      <div class="modal-body">
        <table class='table table-bordered'>
          <thead class='thead-dark'>
          <tr>
      <th scope="col">اسم المنتج</th>
      <th scope="col">عدد القطع</th>
      <th scope="col">السعر</th>
      <th scope="col">المجموع</th>
    </tr>
          </thead>
          <?php
    $count=0;
    $minussPrice=0;
    $qry = $conn->query("SELECT * FROM order_items where order_id like $theReceiptNumber order by id desc");
    while($row=$qry->fetch_assoc()):
     $productName= $row["product_id"];
     if($row['casee']){
					$color='color:black';
					$minuss=null;
						}else{
					$color='color:red';
					$minuss='-';
					$minussPrice +=$row['price'];
						}
    ?>
    <tr style='<?php echo $color; ?>'>
      <th scope=""><?php echo $conn->query("SELECT name FROM products where id like  $productName  ")->fetch_column();
							?></th>
      <td><?php echo $minuss.$row['qty'] ?></td>
      <td><?php echo $row['price'] ?></td>
      <td><?php echo $row['amount'] ?></td>
    </tr>
    <?php
    endwhile;?>
</table>
<br>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">اغلاق</button>
      </div>
    </div>
  </div>
        </div>
</div>






<div class="container-fluid o-field" style='margin-top:80px'>
<div class='d-flex justify-content-around'>
<h4 class='text-left'>استرجاع المواد</h4>
<button type="button" class="btn btn-info" data-toggle="modal" data-target="#exampleModalCenter1">مشاهدة قائمة المواد</button>   
<h4 class='text-right'>NO.<?php echo $theReceiptNumber ?></h4></div>



<hr style='
        height: 2px;
        background: black;'>
        <h5 class='text-center'>قائمة المواد المسترجعة</h5>
        <div class='d-flex justify-content-around'>
        <button class="btn btn-info  pt-2 pb-2 m-2 thePrint" type="button"> طباعة </button>
        <input class='form-control text-right theQr float-right mb-2' placeholder='Qr استرجاع عن طريق ال' type='text' style='width:250px'>
  </div>
<table class="table " id='o-list'>
  <thead class="thead-dark">
    <tr>
      <th scope="col" class='text-center'>اسم المنتج</th>
      <th scope="col" class='text-center'>السعر</th>
    </tr>
  </thead>
  <tbody>
 
  </tbody>
</table>

  </div>
  <?php }else{

    ?>
<input type='text' class='theQr2 text-center' style='margin:10px;margin-top:100px;height:40px;border:1px black solid;border-radius:5px' placeholder=' Qr قم بقراءة ال'>

<?php
  }
   ?>
<script>
   

    $(document).ready(function(){
     
    
      $('.theQr2').on('keypress',function(e) {
      if(e.which == 13) {
var theId=$('.theQr2').val();
        window.location.href=("http://localhost/kruxton/Retrieving-products.php?receiptNumber="+theId);
      }
    })

    
    $('.thePrint').on('click',function(e) {
     
        var theGetId='<?php echo $theReceiptNumber ;?>'
        var nw = window.open('receipt.php?id='+theGetId,"_blank","width=900,height=600")
                            setTimeout(function(){
                                nw.print()
                                setTimeout(function(){
                                    nw.close()
                                    location.reload()
                                },500)
                            },500)
    })

$('.theQr2 , .theQr').focus();

$('.theQr').on('keypress',function(e) {
if(e.which == 13) {
var theQr = $('.theQr').val();  
        $.ajax({
            url:"billing/codeQr.php?codeRetrieving="+theQr+"&receiptNumber=<?php echo $theReceiptNumber ?>", 
            method:"POST",  
            dataType:"text",  
            success:function(data){  
              if(data){
                alert(data)
                data = JSON.parse(data)
        // if($('#o-list tr[data-id="'+data.id+'"]').length > 0){
           
        //     var tr = $('#o-list tr[data-id="'+data.id+'"]')
        //     var qty = tr.find('[name="qty[]"]').val();
        //         qty = parseInt(qty) + 1;
        //         qty = tr.find('[name="qty[]"]').val(qty).trigger('change')
             
        //     return false;
        // } 
        var tr = $('<tr class="o-item"></tr>')
        tr.attr('data-id',data.id)


        tr.append('<td class="text-center"><input type="hidden" name="item_id[]" id="" value=""><input type="hidden" name="product_id[]" id="" value="'+data.id+'">'+data.name+' <small class="psmall">('+(parseFloat(data.price).toLocaleString("en-US",{style:'decimal',minimumFractionDigits:2,maximumFractionDigits:2}))+')</small></td>') 


        tr.append('<td class="text-center"><input type="hidden" name="price[]" id="" value="'+data.price+'"><input type="hidden" name="amount[]" id="" value="'+data.price+'"><span class="amount">'+(parseFloat(data.price).toLocaleString("en-US",{style:'decimal',minimumFractionDigits:2,maximumFractionDigits:2}))+'</span></td>') 

        
        // tr.append('<td><span class="btn-rem"><b><i class="fa fa-trash-alt text"></i></b></span></td>')
        $('#o-list tbody').append(tr)
  
              }


             
            //   var selectized = $('#selectt').selectize();
            //   var selectizeoption = selectized[0].selectize;
            //    selectizeoption.clear();
            //    selectized[0].selectize.focus();
            }
         
        }); 


        $('.theQr').val("");

      }
    })
    $(document).on('click', '#o-list .btn-rem', function(){
            $(this).closest('tr').remove()
         })

    })

    
</script>